#include <stdio.h>
#include <stdlib.h>
int main()
{
    int side;
    printf("Enter the side :");
    scanf("%d", &side);
    printf("The ares:%d", side * side);
    return 0;
}
        