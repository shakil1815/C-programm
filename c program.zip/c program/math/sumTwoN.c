#include <stdio.h>
int main()
{
    int a, b, sum;
    printf("Enter the number of a:");
    scanf("%d", &a);
    printf("Enter the number of b:");
    scanf("%d", &b);
    sum = a + b;
    printf("The sum is:%d", sum);
    return 0;
}