#include <stdio.h>
// declaration/prototype
void printshakil();
int main()
{
    printshakil(); // function call
    return 0;
}
// function definition
void printshakil()
{
    printf("Hello Shakil");
}
