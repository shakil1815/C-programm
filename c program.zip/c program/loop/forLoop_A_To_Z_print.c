#include <stdio.h>
int main()
{
    for (char ch = 'A'; ch <= 'Z'; ch++)
    { // বড় হাতের A-Z প্রিন্ট করবে
        printf("%c\n", ch);
    }
    return 0;
}
