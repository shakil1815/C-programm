#include <stdio.h>
int main()
{
    int i = 1; // Initialization
    do
    {
        printf("%d\n", i);
        i++; // Updation
    } while (i <= 5); // Condition
    return 0;
}
