#include <stdio.h>
int main()
{
    for (int i = 1; i <= 100; i++)
    {
        printf("Hello World!!\n");
    }
    return 0;
}
