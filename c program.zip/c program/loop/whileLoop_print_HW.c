#include <stdio.h>
int main()
{
    int i = 1; // Initialization
    while (i <= 10)
    { // Condition
        printf("Hello World\n");
        i++; // Updation
    }
    return 0;
}
