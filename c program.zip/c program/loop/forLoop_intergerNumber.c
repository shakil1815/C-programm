#include <stdio.h>
int main()
{
    for (int i = 1; i <= 10; i++)
    { // 1 থেকে 10 পর্যন্ত প্রিন্ট করবে
        printf("%d\n", i);
    }
    return 0;
}
